//
//  File.swift
//  Exercicio_POO
//
//  Created by Usuário Convidado on 28/03/23.
//

import Foundation

protocol Higiene{
    
    func lavarMao()
}
